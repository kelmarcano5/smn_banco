update smn_banco.smn_plantilla_movimiento_bancario set pmb_estatus=${fld:status}
where smn_plantilla_movimiento_bancario_id=${fld:plantilla_id}