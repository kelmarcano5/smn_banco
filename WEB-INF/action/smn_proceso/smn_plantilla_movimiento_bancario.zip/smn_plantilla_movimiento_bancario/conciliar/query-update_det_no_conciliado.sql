update smn_banco.smn_plantilla_movimiento_bancario_det set pmd_estatus=${fld:status}
where smn_plantilla_movimiento_bancario_det_id=${fld:detalle_id};