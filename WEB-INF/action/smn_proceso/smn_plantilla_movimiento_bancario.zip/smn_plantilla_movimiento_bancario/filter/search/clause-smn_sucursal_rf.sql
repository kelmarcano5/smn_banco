 and
 	smn_banco.smn_plantilla_movimiento_bancario.smn_sucursal_rf=${fld:smn_sucursal_rf}