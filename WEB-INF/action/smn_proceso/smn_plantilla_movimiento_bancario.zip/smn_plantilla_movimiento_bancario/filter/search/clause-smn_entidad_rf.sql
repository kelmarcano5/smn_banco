 and
 	smn_banco.smn_plantilla_movimiento_bancario.smn_entidad_rf=${fld:smn_entidad_rf}