 and
 	smn_banco.smn_plantilla_movimiento_bancario.pmb_fecha_registro=${fld:pmb_fecha_registro}