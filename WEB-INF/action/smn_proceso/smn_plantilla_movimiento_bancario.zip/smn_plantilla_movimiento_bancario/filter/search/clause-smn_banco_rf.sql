 and
 	smn_banco.smn_plantilla_movimiento_bancario.smn_banco_rf=${fld:smn_banco_rf}