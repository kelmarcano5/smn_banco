 and
 	upper(smn_banco.smn_plantilla_movimiento_bancario.pmb_estatus) like upper(${fld:pmb_estatus})