 and
 	smn_banco.smn_plantilla_movimiento_bancario.smn_cuenta_bancaria_rf=${fld:smn_cuenta_bancaria_rf}