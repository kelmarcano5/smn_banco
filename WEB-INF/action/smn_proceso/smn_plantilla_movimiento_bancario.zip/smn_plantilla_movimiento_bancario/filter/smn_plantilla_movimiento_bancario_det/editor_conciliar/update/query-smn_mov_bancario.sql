select 
 *
  
from smn_banco.smn_movimiento_bancario
