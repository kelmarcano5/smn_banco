delete from smn_banco.smn_rel_plant_mov_bancario
 WHERE  smn_plantilla_movimiento_bancario_det_id= ${fld:id}