select	
	*
from 
	smn_banco.smn_plantilla_movimiento_bancario_det
where 
	smn_plantilla_movimiento_bancario_det_id = ${fld:id}


