select ${seq:nextval@smn_banco.seq_smn_plantilla_movimiento_bancario_det} as id
