delete from smn_banco.smn_plantilla_movimiento_bancario where smn_plantilla_movimiento_bancario_id = ${fld:id}
