search();
alertBox('Documento procesado', '${lbl:b_continue_button}', null, null);
