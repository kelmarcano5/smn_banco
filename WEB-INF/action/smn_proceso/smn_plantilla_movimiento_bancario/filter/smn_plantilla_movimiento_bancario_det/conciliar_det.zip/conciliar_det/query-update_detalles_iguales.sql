update smn_banco.smn_plantilla_movimiento_bancario_det set pmd_estatus='CN' 
where smn_plantilla_movimiento_bancario_det_id=${fld:detalle_id};

update smn_banco.smn_plantilla_movimiento_bancario_det set pmd_estatus='CN' 
where smn_plantilla_movimiento_bancario_det_id=${fld:detalle_id2};