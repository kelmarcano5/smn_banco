select ${seq:nextval@smn_banco.seq_smn_movimiento_bancario} as id
