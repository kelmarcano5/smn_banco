select	
	*
from 
	smn_banco.smn_movimiento_bancario
where 
	smn_movimiento_bancario_id = ${fld:id}


